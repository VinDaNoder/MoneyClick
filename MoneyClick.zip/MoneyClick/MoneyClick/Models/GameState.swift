//
//  GameState.swift
//  MoneyClick
//
//  Created by Vinny Stark on 12/7/24.
//

import Foundation

class GameState: ObservableObject {
    @Published var dollars = 0
    @Published var PointsPerDollar = 0
    @Published var DollarGenerators:[DollarGenerator] = [
        DollarGenerator(name: "$5 Bill Printer Purchase", PointPerDollar: 5, generatorCost:20, level: 0),
        DollarGenerator(name: "$10 Bill Creator Hire", PointPerDollar: 10, generatorCost:75, level: 0),
        DollarGenerator(name: "$20 Bill Machine Purchase", PointPerDollar: 20, generatorCost:1000, level: 0),
        DollarGenerator(name: "$50 Bill Printing Room Purchase", PointPerDollar: 50, generatorCost:10000, level: 0),
        DollarGenerator(name: "$100 Bill Factory Purchase", PointPerDollar: 100, generatorCost:1000000, level: 0),
        DollarGenerator(name: "Money Creation Officer Application", PointPerDollar: 10000, generatorCost:10000000, level: 0),
        DollarGenerator(name: "Become Vice President of the U.S.", PointPerDollar: 100000, generatorCost:100000000, level: 0),
        DollarGenerator(name: "Become President of the U.S.", PointPerDollar: 1000000, generatorCost:1000000000, level: 0)
    ]
    
        var timer:Timer?
    
        init(){
            self.dollars = 1
            self.timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: {_ in
            self.tick()
            })
        }
        func click(){
            self.dollars += 1
        }
        
    func purchase(dollarGenerator:DollarGenerator){
        if dollarGenerator.generatorCost <= self.dollars {
            self.dollars -= dollarGenerator.generatorCost
            self.PointsPerDollar += dollarGenerator.PointPerDollar
            
            var newDollarGenerators = self.DollarGenerators
            let index = newDollarGenerators.firstIndex(where: {$0.id == dollarGenerator.id })!
            newDollarGenerators[index].level += 1
            self.DollarGenerators = newDollarGenerators
        }
    }
        func tick(){
            self.dollars += self.PointsPerDollar
        }
    }
