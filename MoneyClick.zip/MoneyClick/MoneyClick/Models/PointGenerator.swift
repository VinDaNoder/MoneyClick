//
//  PointGenerator.swift
//  MoneyClick
//
//  Created by Vinny Stark on 12/7/24.
//
import Foundation

struct DollarGenerator: Identifiable {
    var id  = UUID()
    var name:String
    var PointPerDollar:Int
    var generatorCost:Int
    var level:Int
}
