//
//  MoneyClickApp.swift
//  MoneyClick
//
//  Created by Vinny Stark on 12/7/24.
//

import SwiftUI

@main
struct MoneyClickApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
