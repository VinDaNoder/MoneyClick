//
//  ContentView.swift
//  MoneyClick
//
//  Created by Vinny Stark on 12/7/24.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var gameState = GameState()
    
    var body: some View {
        VStack {
            Text("SmartPixel Studios Presents")
            Text("MoneyClick")
                .font(.system(size: 36))
            Text("v1.0.0")
                
            
            Button(action:{self.gameState.click()}){
                Text("Tap Here!")}
            .padding(15)
            .background(Color.green)
            .cornerRadius(10)
            .foregroundStyle(Color.white)
            
            Text("$\(gameState.dollars)")
                .font(.headline)
            
            if self.gameState.PointsPerDollar > 0 {
                Text("$/sec: \(gameState.PointsPerDollar)")
            }
            
            List(gameState.DollarGenerators){DollarGenerator in
                HStack{
                    VStack(alignment:.leading){
                        Text(DollarGenerator.name)
                        Text("Level \(DollarGenerator.level)")
                        Text("$/sec: \(DollarGenerator.PointPerDollar)")
                        Text("Price: $\(DollarGenerator.generatorCost)")
                    }
                    Spacer()
                    Group {
                        Button(action:{
                            self.gameState.purchase(dollarGenerator: DollarGenerator)
                        }){Text("Purchase")}
                            .buttonStyle(BorderlessButtonStyle())
                            .disabled(self.gameState.dollars < DollarGenerator.generatorCost)
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
